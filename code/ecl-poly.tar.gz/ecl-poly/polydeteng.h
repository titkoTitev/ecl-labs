/*
  polydetect header file
*/

#ifndef _BSD_SOURCE
#define _BSD_SOURCE
#endif

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <err.h>
#include <signal.h>
#include <ctype.h>
#include <pcap.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>


#define SKIP 1			// how many bytes to skip
#define ALARM 300		// alarm threshold

char nopz[256];			// global hash table

/* prototypes */
int polycheck(char *buffer, u_int16_t length);
void make_table(void);
