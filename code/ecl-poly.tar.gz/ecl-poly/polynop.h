/*
    polynop external header file

    This function will scan [sled] to determine the amount of
    usable bytes for NOP-padding by counting the remaining
    0x90 NOPs, the reason for this is so this could be used
    along with dynamic shellcode sizes for "true" polymorphism.

    Blacklisting is supported both by the badchars variable where
    the input is simply a list of forbidden characters, and the
    badregs variable, where the input is a list of registers that
    should not be tempered with.

    Read ecl-poly.txt for the concept behind this, or USAGE for
    general usage information.  
*/

void polynopad(char *sled, char *badchars, char *badregs);
