#include "polydeteng.h"
#include "polynopeng.h"

/*
 * check for ALARM consecutive nop replacements,
 * disregarding SKIP unknown bytes
 */

int polycheck(char *buffer, u_int16_t length)
{
  u_int16_t index, nops, skipped;

  if (length < ALARM) return 0;

  index = 0;
  nops = 0;
  skipped = 0;

  while (index < length)
    {
      if (nopz[(u_char)buffer[index++]])
        nops++;
      else
        if (skipped < SKIP)
          skipped++;
        else
          nops = 0;

      if (nops == ALARM) return 1;
    }

  return 0;
}


/*
 * create the hash table for the nop replacements 
 */

void make_table(void)
{
  int i;

  // fill in the known nops into the array
  bzero(nopz,256);
  for ( i=0; i<(sizeof(IA32_nops)/sizeof(struct IA32_nop)); i++ )
    nopz[(u_char)IA32_nops[i].code] = 1;
 
  nopz[0x90] = 1; // regular nop
  /* now we add instruction prefixes which could
     also be used as nop-replacements */
  // group 1
  nopz[0x0f] = 1; // two byte instruction prefix
  nopz[0xf0] = 1; // lock
  nopz[0xf2] = 1; // repne/repnz
  nopz[0xf3] = 1; // rep/repe/repz
  // group 2
  nopz[0x2e] = 1; // CS segment override
  nopz[0x36] = 1; // SS segment override
  nopz[0x3e] = 1; // DS segment override
  nopz[0x26] = 1; // ES segment override
  nopz[0x64] = 1; // FS segment override
  nopz[0x65] = 1; // GS segment override 
  // groups 3 and 4
  nopz[0x66] = 1; // operand-size override
  nopz[0x67] = 1; // address-size override
}
