/*
 * Yuri Gushin - <yuri@ecl-labs.org>
 * ECL Team
 * 
 */

#include "polydeteng.h"

/* ======= global variables ======= */

pcap_t *	interface;			// pcap device descriptor
u_int 		counter;		   	// number of suspected packets
int 		ip_offset;			// offset to ip struct (datalink dependant)
int		verbose;			// verbose mode variable
int		rdns;				// reverse dns lookup variable

/* ====== function prototypes ===== */

void 		banner();
void 		usage(char *);
void            status_exit();
char *		copy_argv(char **);
int 		datalink_offset(int);
void 		packet_received(u_char *, const struct pcap_pkthdr *, const u_char *);
void 		print_packet_data(char *, u_int16_t);
char *		reverse_dns(struct in_addr);

/* ============  code  ============ */
int main(int argc, char **argv)
{
  int ch,promisc;
  char *dev,*bpf;
  char error[PCAP_ERRBUF_SIZE];
  struct bpf_program filter; 
  bpf_u_int32 mask, net;

  banner();
  counter = 0;
  verbose = 0;
  promisc = 0;
  rdns = 1;
  dev = NULL;

  while (( ch = getopt(argc,argv,"i:vprh")) != -1)
    switch(ch)
      {
      case 'i':
	dev = optarg;
	break;
      case 'v':
	verbose++;
	break;
      case 'p':
	promisc++;
	break;
      case 'r':
	rdns--;
	break;
      case 'h':
	usage(argv[0]);
      default:
	usage(argv[0]);
      }

  bpf = copy_argv(&argv[optind]);

  // create the hash table for our nops
  make_table();
  
  // let's get busy with pcap
  if ((interface = pcap_open_live(dev, 65535, promisc, 1000, error)) == NULL)
    errx(1,"pcap_open_live error: %s\n",error);
  if ((ip_offset = datalink_offset(pcap_datalink(interface))) < 0)
    errx(1,"unsupported media type on device %s\n", (dev)?dev:"any");
  if (pcap_lookupnet(dev, &net, &mask, error) < 0)
    {
      net = 0;
      mask = 0;
      warnx("pcap_lookupnet warning: %s\n",error);
    }
  printf("Device: %s\nMedia type: %s\n", (dev)?dev:"any",
         pcap_datalink_val_to_name(pcap_datalink(interface)));
  if (bpf)
    {
      if (pcap_compile(interface, &filter, bpf, 1, net) < 0)
	errx(1,"pcap_compile error: %s\n",pcap_geterr(interface));
      if (pcap_setfilter(interface, &filter) < 0)
	errx(1,"pcap_setfilter error: %s\n",pcap_geterr(interface));
      pcap_freecode(&filter);
      printf("BPF expression: %s\n",bpf);
      free(bpf);
    }

  printf("Looking for IA32 polymorphic payload patterns...\n\n");

  // make sure we print our statistics before exiting
  signal(SIGINT, status_exit);
  signal(SIGTERM, status_exit);
  signal(SIGQUIT, status_exit);
  signal(SIGABRT, status_exit);

  // start our endless sniffer loop
  pcap_loop(interface,-1,packet_received,NULL);

  return 0;
}

// function called whenever a packet is received
void packet_received(u_char *args, const struct pcap_pkthdr *header, const u_char *packet)
{
  struct ip *ip;
  struct tcphdr *tcp;
  struct udphdr *udp;
  struct icmp *icmp;
  u_int16_t length;
  char *data,*src,*dst;
  time_t ttime;
  struct tm ctime;
  char ftime[20];

  ip = (struct ip*)(packet+ip_offset);
  if (ip->ip_v != 4) return;

  switch(ip->ip_p)
    {
    case IPPROTO_TCP:
      tcp = (struct tcphdr*)((char *)ip+(ip->ip_hl*4));	// tcp header offset
      length = ntohs(ip->ip_len) - (ip->ip_hl*4) - (tcp->th_off*4);
      data = (char *)tcp+tcp->th_off*4;
      if (polycheck(data, length))
	{
	  ttime = time(NULL);
	  ctime = *(localtime(&ttime));
	  strftime(ftime, 20, "%d/%m/%Y %T", &ctime);
	  src = strdup(reverse_dns(ip->ip_src));
	  dst = strdup(reverse_dns(ip->ip_dst));
	  printf("%s Alarm: TCP %s:%d -> %s:%d\n", ftime, src,
		 ntohs(tcp->th_sport), dst, ntohs(tcp->th_dport));
	  free(src);
	  free(dst);
	  counter++;
	  if (verbose) print_packet_data(data, length);
	}
      break;
    case IPPROTO_UDP:
      udp = (struct udphdr*)((char *)ip+(ip->ip_hl*4));	// udp header offset
      length = ntohs(ip->ip_len) - (ip->ip_hl*4) - sizeof(struct udphdr);
      data = (char *)udp+sizeof(struct udphdr);
      if (polycheck(data, length))
	{
          ttime = time(NULL);
          ctime = *(localtime(&ttime));
          strftime(ftime, 20, "%d/%m/%Y %T", &ctime);
          src = strdup(reverse_dns(ip->ip_src)); 
          dst = strdup(reverse_dns(ip->ip_dst)); 
	  printf("%s Alarm: UDP %s:%d -> %s:%d\n", ftime, src,
		 ntohs(udp->uh_sport), dst, ntohs(udp->uh_dport));
	  free(src);
	  free(dst);
	  counter++;
	  if (verbose) print_packet_data(data, length);
	}
      break;
    case IPPROTO_ICMP:
      icmp = (struct icmp*)((char *)ip+(ip->ip_hl*4));	// icmp header offset
      length = ntohs(ip->ip_len) - (ip->ip_hl*4) - sizeof(struct icmp); 
      data = (char *)icmp+sizeof(struct icmp);
      if (polycheck(data, length))
	{
          ttime = time(NULL);
          ctime = *(localtime(&ttime));
          strftime(ftime, 20, "%d/%m/%Y %T", &ctime);
          src = strdup(reverse_dns(ip->ip_src)); 
          dst = strdup(reverse_dns(ip->ip_dst)); 
	  printf("%s Alarm: ICMP %s->%s type %d code %d\n",
		 ftime, src, dst, icmp->icmp_type, icmp->icmp_code);
	  free(src);
	  free(dst);
	  counter++;
	  if (verbose) print_packet_data(data, length);
	}
      break;
    }
}

// gets the offset to the ip struct by the datalink type

int datalink_offset(int type)
{
  switch(type)
    {
#ifdef DLT_RAW
    case DLT_RAW:       return 0;
#endif   
#ifdef DLT_EN10MB
    case DLT_EN10MB:	return 14;
#endif
#ifdef DLT_PPP
    case DLT_PPP:       return 4;
#endif
#ifdef DLT_LINUX_SLL
    case DLT_LINUX_SLL: return 16;
#endif
#ifdef DLT_SLIP
    case DLT_SLIP:      return 16;
#endif
#ifdef DLT_PPP_BSDOS
    case DLT_PPP_BSDOS:	return 24;
#endif
#ifdef DLT_SLIP_BSDOS
    case DLT_SLIP_BSDOS:return 24;
#endif
#ifdef DLT_FDDI
    case DLT_FDDI:	return 21;
#endif
#ifdef DLT_IEEE802
    case DLT_IEEE802:   return 22;
#endif
#ifdef DLT_NULL
    case DLT_NULL:      return 4;
#endif
#ifdef DLT_LOOP
    case DLT_LOOP:	return 4;
#endif
#ifdef DLT_PPP_ETHER
    case DLT_PPP_ETHER:	return 12;
#endif
    default:		return -1;
  }
}

// copies arguments into a new buffer concatenating them with spaces                                    
char *copy_argv(char **argv)
{
  u_int len = 0;
  char *buf, *src, *dst, **p;

  p = argv;
  if (*p == 0) return 0;
  while (*p)
    len += strlen(*p++) + 1;
  if ((buf = (char *)malloc(len)) == NULL)
    {
      printf("memory allocation error\n");
      exit(1);
    }
  p = argv;
  dst = buf;
  while ((src = *p++) != NULL) {
    while ((*dst++ = *src++) != '\0')
      ;
    dst[-1] = ' ';
  }
  dst[-1] = '\0';

  return buf;
}

void print_packet_data(char *data, u_int16_t length)
{
  int i = 0;

  printf("Data length: %d bytes\nData content:\n", length);
  
  while(i < length)
    {
      int j;
      for ( j=0; j<16; j++ )
	{
	  if (i+j < length)
	    printf("%02X ", data[i+j] & 0xff);
	  else
	    printf("   ");
	}
      for ( j=0; (j<16) && (i<length); j++, i++ )
	{
	  if (isprint(data[i]))
	    printf("%c", data[i]);
	  else
	    printf(".");
	}
      printf("\n");
    }
}

// reverse dns an ip address with double checking

char *reverse_dns(struct in_addr ip_address)
{
  struct hostent *host1,*host2;

  if (!rdns) return inet_ntoa(ip_address);

  host1 = gethostbyaddr((char *)&ip_address, 4, AF_INET);
  if (host1)
    {
      host2 = gethostbyname(host1->h_name);
      while (host2->h_addr_list[0])
	{
	  if (!memcmp(host2->h_addr_list[0], &ip_address.s_addr, 4))
	    return host2->h_name;
	  host2->h_addr_list++;
	}
    }
  return inet_ntoa(ip_address);
}

void usage(char *name)
{
  printf("Usage: %s [-ivprh] [ expression ]\n"
         "\t-i: interface to snoop on (default = any)\n"
         "\t-v: verbose mode\n"
         "\t-p: promiscuous mode\n"
	 "\t-r: disable hostname lookup\n"
         "\t-h: help\n"
         "\texpression is a boolean filter expression\n",
         name);
  exit(-1);
}

void banner(void)
{
  printf("\t-== polydetect by Yuri Gushin ==-\n"
         "\t-==   <yuri@eclipse.org.il>   ==-\n"
         "\t-==     ECL Security R&D      ==-\n"
         "\n");
}

void status_exit()
{
  struct pcap_stat stats;

  if (pcap_stats(interface, &stats) == 0)
    {
      printf("\n\nStatistics:\n");
      printf("%u packets received by filter\n", stats.ps_recv);
      printf("%u packets dropped by kernel\n", stats.ps_drop);
      printf("%u packets suspected\n", counter);
    }
  fflush(stdout);
  pcap_close(interface);
  exit(0);
}
