#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>


int handlah(int sd)
{
  char buffer[1024], name[2048];
  int bytes;

  strcpy(buffer, "1d3nt1f7: ");
  bytes = send(sd, buffer, strlen(buffer), 0);
  if (bytes == -1) return -1;
  bytes = recv(sd, name, sizeof(name), 0);
  if (bytes == -1) return -1;
  name[bytes - 1] = '\0';
  sprintf(buffer, "w0rd %s\n", name);
  bytes = send(sd, buffer, strlen(buffer), 0);
  if (bytes == -1) return -1;

  return 0;
}

int main(int argc, char **argv)
{
  int sd, c, cs;
  struct sockaddr_in server, client;

  if (argc < 2)
    {
      fprintf(stderr, "usage: %s port\n", argv[0]);
      exit(-1);
    }

  sd = socket(AF_INET, SOCK_STREAM, 0);
  if (sd == -1)
    {
      perror("socket");
      return 2;
    }

  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons(atoi(argv[1]));
  server.sin_family = AF_INET;

  if (bind(sd, (struct sockaddr *)&server, sizeof(server)) == -1)
    {
      perror("bind");
      exit(-1);
    }
  if (listen(sd, 10) == -1)
    {
      perror("listen");
      exit(-1);
    }

  while (1)
    {
      cs = sizeof(struct sockaddr);
      c = accept(sd, (struct sockaddr *)&client, &cs);
      if (c == -1)
	{
	  perror("accept");
	  exit(-1);
	}
      printf("%s connected.\n", inet_ntoa(client.sin_addr));
      if (handlah(c) == -1)
	printf("couldn't handle %s !\n", argv[0]);
      close(c);
    }
  return 0;
}
